//test
export const getCount = state => {
    return state.count
};
export const getCart = state =>{
    return state.cart;
};
export const getItems = state =>{
    return state.items;
}