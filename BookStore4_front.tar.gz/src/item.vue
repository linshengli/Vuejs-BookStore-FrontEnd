<template>
    <div class="container">
        <tr>

        </tr>
    </div>
</template>
<script>
    export default{
        props: ["item"],
    }
</script>