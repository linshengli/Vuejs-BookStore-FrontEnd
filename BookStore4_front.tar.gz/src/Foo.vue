<template>

    <div>foo</div>

</template>
<script>
    export default{

    }
</script>