<template>

    <div>Bar</div>

</template>
<script>
    export default{

    }
</script>